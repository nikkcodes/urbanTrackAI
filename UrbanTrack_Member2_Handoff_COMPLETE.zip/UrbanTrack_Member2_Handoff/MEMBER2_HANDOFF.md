# UrbanTrackAI — Complete Member-2 Data Handoff

## Purpose
This package is the downstream data boundary from Member 2 to Member 3. It preserves what is actually present in the supplied Member-2 handoff and explicitly marks missing data as `null` / `UNAVAILABLE`.

## Empirical scope
- Dataset: AI City Challenge 2022 Track 1 / CityFlowV2
- MVP cameras actually processed: `CAM_S01_C001`, `CAM_S01_C002`, `CAM_S01_C003`
- Original benchmark scope referenced by the project: 46 cameras; **not validated here**.
- Raw observations: 21,810 aggregate count; the uploaded handoff does not contain the original frame-level observation table.
- Tracklets: 384
- Persisted embeddings: 322 / 384, 512-D
- Inferred identity hypotheses: 355
- Trajectory hypotheses: 355

## Critical semantics
1. `identity_id` is Member-2 inferred identity, not GT.
2. GT is evaluation-only and must never enter operational inference.
3. Time is video-relative, with an official synchronized overlay using S01 offsets.
4. World coordinates are local `cityflow_world` planar meters, not GPS/WGS84.
5. Plate text is unavailable/censored; `plate_text=null`.
6. Route/road/junction association is currently unavailable for this 3-camera handoff.
7. No calibrated per-trajectory probability is emitted.
8. Calibration metrics apply to the pairwise identity-score calibration model; they are not trajectory calibration metrics.
9. SIMULATED data is not included in operational outputs.

## Source preservation
Original source output files are copied under `source_snapshot/` without modification. The normalized `outputs/trajectories.json` is explicitly a contract projection; it does not overwrite the source snapshot.

## Important limitation
The uploaded ZIP alone does not contain the original frame-level `observations.json`, calibration matrix numeric contents, intrinsic/extrinsic camera parameters, camera GPS/location/orientation metadata, or the 512-D embedding vectors. These are therefore not fabricated into this package. If Member 3 requires those exact raw values, the corresponding source files must be transferred from the project repository/data bundle.
