# Coverage and Limitations

| Data item | Available | Complete | Exact limitation |
|---|---|---|---|
| Genuine GPS/WGS84 camera coordinates | No | No | No authoritative latitude/longitude in supplied handoff |
| Readable ANPR/license plate text | No | No | AI City plates are censored; plate text is null/unavailable |
| All CityFlowV2 cameras | No | No | Only C001/C002/C003 processed for MVP |
| Complete camera→road/junction mapping | No | No | No complete road graph association in current handoff |
| Complete road-associated trajectories | No | No | Current trajectories are unassociated-camera hypotheses |
| Calibrated identity probabilities | Partial | No | Platt calibration model/metrics exist; per-identity calibrated probabilities are not emitted |
| Calibrated trajectory probabilities | No | No | No validated trajectory calibration output |
| Route probabilities | No | No | No populated road-network route hypotheses |
| Camera reliability | Yes | For 3 processed cameras | Member-2 reliability output exists for C001-C003 only |
| Canonical timestamps | Partial | No | Video-relative timestamps plus synchronized overlay; not UTC |
| Raw frame-level observations | Aggregate only | No | 21,810 count is known, but raw table is absent from supplied ZIP |
| 512-D embedding vectors | Coverage only | No | 322/384 coverage and model metadata available; vectors absent from ZIP |
| Ground truth | Yes for evaluation | Yes within stated evaluation artifacts | Must remain evaluation-only |
| Simulated operational data | No | N/A | No simulated values included |

## Camera scope
C001: 107 tracklets, 7,229 observations, 94 embeddings, 195.5 s.
C002: 125 tracklets, 6,702 observations, 115 embeddings, 211.0 s; MSMT17 model guarded against cross-model appearance matching.
C003: 152 tracklets, 7,879 observations, 113 embeddings, 199.6 s.
